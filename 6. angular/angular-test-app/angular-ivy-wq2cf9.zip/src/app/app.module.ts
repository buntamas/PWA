import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CanLoadTest } from '../core/can-load-test';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WelcomeChildComponent } from './components/welcome/welcome-child.component';
import { ExponentialStrengthDirective } from '../core/exponential-strength.pipe';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    WelcomeChildComponent,
    ExponentialStrengthDirective,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    FormsModule,
  ],
  providers: [CanLoadTest],
  bootstrap: [AppComponent],
})
export class AppModule {}
