import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

export interface StringWrapper {
  value: string;
}

@Component({
  selector: 'app-welcome-child',
  template: '<div>Change detection demo: {{ stringWrapper.value }}</div>',
})
export class WelcomeChildComponent {
  @Input() stringWrapper: StringWrapper;

  constructor() {}
}
