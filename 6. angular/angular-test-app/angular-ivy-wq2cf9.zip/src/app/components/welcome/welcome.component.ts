import {
  Component,
  ElementRef,
  ViewChild,
} from '@angular/core';
import { MatInput } from '@angular/material/input';

export interface StringWrapper {
  value: string;
}

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent {
  @ViewChild('input') inputRef: ElementRef<MatInput>;

  inputValue = '';
  valueWithCdCheck: StringWrapper = { value: 'initial' };

  constructor() {}

  onClick(_event: any) {
    this.inputRef.nativeElement.focus();
    this.valueWithCdCheck.value = this.inputValue;
  }
}
